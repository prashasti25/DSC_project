package com.example.signin;

public class user {
    public String fullname,agee,email;
    public user(){

    }
    public user(String full,String age,String email){
        this.fullname=full;
        this.agee=age;
        this.email=email;
    }
}
